import React, { useState } from 'react';
import { Building2, TrendingUp, MapPin, Percent, ArrowRight, Home, Factory } from 'lucide-react';

const PROPERTIES = [
  {
    id: 'RE-001',
    name: 'The Azure Tower',
    location: 'Miami, FL',
    type: 'Commercial',
    icon: Building2,
    pricePerShare: 250,
    totalShares: 10000,
    availableShares: 1250,
    yield: 8.5,
    occupancy: 92,
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'RE-002',
    name: 'Silicon Valley Logistics Hub',
    location: 'San Jose, CA',
    type: 'Industrial',
    icon: Factory,
    pricePerShare: 500,
    totalShares: 5000,
    availableShares: 400,
    yield: 11.2,
    occupancy: 100,
    image: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'RE-003',
    name: 'Metro View Residences',
    location: 'Austin, TX',
    type: 'Residential',
    icon: Home,
    pricePerShare: 100,
    totalShares: 25000,
    availableShares: 8500,
    yield: 6.8,
    occupancy: 88,
    image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&q=80&w=800'
  }
];

const RealEstateDashboard: React.FC = () => {
  const [selectedProperty, setSelectedProperty] = useState<string | null>(null);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-display font-black text-white uppercase tracking-tight">Real Estate Portfolio</h2>
          <p className="text-sm text-slate-400 mt-1">Fractional ownership and yield generation</p>
        </div>
        <div className="flex gap-4">
          <div className="bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-right">
            <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Total Value</div>
            <div className="text-lg font-mono font-bold text-white">$0.00</div>
          </div>
          <div className="bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-right hidden sm:block">
            <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Avg Yield</div>
            <div className="text-lg font-mono font-bold text-emerald-400">0.00%</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {PROPERTIES.map((property) => {
          const Icon = property.icon;
          return (
            <div key={property.id} className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-3xl overflow-hidden group hover:border-prime-cyan/30 transition-all cursor-pointer" onClick={() => setSelectedProperty(property.id)}>
              <div className="h-48 relative overflow-hidden">
                <img src={property.image} alt={property.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent"></div>
                <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-md border border-white/10 rounded-lg px-3 py-1.5 flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                  <span className="text-xs font-bold text-white uppercase tracking-wider">{property.type}</span>
                </div>
                <div className="absolute bottom-4 left-4 right-4">
                  <h3 className="text-xl font-display font-black text-white uppercase tracking-wide mb-1">{property.name}</h3>
                  <div className="flex items-center gap-1 text-slate-300 text-xs">
                    <MapPin size={12} />
                    <span>{property.location}</span>
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Price / Share</div>
                    <div className="text-lg font-mono font-bold text-white">${property.pricePerShare}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Est. Yield</div>
                    <div className="text-lg font-mono font-bold text-emerald-400 flex items-center gap-1">
                      {property.yield}% <TrendingUp size={14} />
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Occupancy</div>
                    <div className="text-sm font-mono font-bold text-white flex items-center gap-1">
                      {property.occupancy}% <Percent size={12} className="text-slate-500" />
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Available</div>
                    <div className="text-sm font-mono font-bold text-white">{property.availableShares.toLocaleString()}</div>
                  </div>
                </div>
                
                <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden mb-4">
                  <div className="h-full bg-prime-cyan" style={{ width: `${((property.totalShares - property.availableShares) / property.totalShares) * 100}%` }}></div>
                </div>
                <div className="flex justify-between text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-6">
                  <span>Funded</span>
                  <span>{(((property.totalShares - property.availableShares) / property.totalShares) * 100).toFixed(1)}%</span>
                </div>

                <button className="w-full py-3 bg-white/5 hover:bg-prime-cyan hover:text-black border border-white/10 hover:border-prime-cyan rounded-xl text-xs font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 group-hover:shadow-[0_0_20px_rgba(0,240,255,0.2)]">
                  Invest Now <ArrowRight size={14} />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default RealEstateDashboard;
