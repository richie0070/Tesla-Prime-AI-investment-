import React, { useState } from 'react';
import { User, TradingSettings } from '../types';
import ConfirmationModal from './ConfirmationModal';
import { Marketplace } from './Marketplace';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { storage, auth } from '../firebase';
import { sendPasswordResetEmail } from 'firebase/auth';

interface SettingsPanelProps {
  userProfile?: User;
  settings: TradingSettings;
  onUpdateSettings: (settings: TradingSettings) => void;
  onUpdateUser?: (user: User) => void;
}

export const SettingsPanel: React.FC<SettingsPanelProps> = ({ userProfile, settings, onUpdateSettings, onUpdateUser }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'marketplace' | 'profile' | 'security' | 'trading' | 'notifications' | 'kyc'>('overview');
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [uploading, setUploading] = useState<boolean>(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [confirmModal, setConfirmModal] = useState<{ isOpen: boolean, title: string, message: string, type: 'danger' | 'warning' | 'info', onConfirm: () => void }>({
    isOpen: false,
    title: '',
    message: '',
    type: 'info',
    onConfirm: () => {}
  });

  const handleSettingChange = (key: keyof TradingSettings, value: any) => {
    onUpdateSettings({ ...settings, [key]: value });
  };

  const handleNotificationChange = (key: keyof TradingSettings['notifications'], value: boolean) => {
    onUpdateSettings({
      ...settings,
      notifications: { ...settings.notifications, [key]: value }
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !userProfile) return;

    setUploading(true);
    setUploadError(null);
    setUploadProgress(0);

    try {
      const fileRef = ref(storage, `kyc/${userProfile.id}/${file.name}`);
      const uploadTask = uploadBytesResumable(fileRef, file);

      uploadTask.on(
        'state_changed',
        (snapshot) => {
          const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          setUploadProgress(progress);
        },
        (error) => {
          console.error("Upload failed:", error);
          setUploadError("Failed to upload document. Please try again.");
          setUploading(false);
        },
        async () => {
          const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
          if (onUpdateUser) {
            onUpdateUser({ ...userProfile, kyc: 'pending', kycDocumentUrl: downloadURL } as any);
          }
          setUploading(false);
          setUploadProgress(100);
          setTimeout(() => setUploadProgress(0), 3000);
        }
      );
    } catch (error) {
      console.error("Error initiating upload:", error);
      setUploadError("An error occurred. Please try again.");
      setUploading(false);
    }
  };

  return (
    <div className="animate-[fadeIn_0.3s] space-y-6">
      {/* Header */}
      <div className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-[2rem] p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-32 bg-prime-cyan/5 blur-[80px] rounded-full pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row gap-8 items-start md:items-center">
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-slate-800 to-black border border-white/20 flex items-center justify-center shadow-2xl relative group">
            <span className="text-3xl font-black text-white">{userProfile?.name?.charAt(0) || 'U'}</span>
            <div className="absolute inset-0 bg-black/50 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer backdrop-blur-sm">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-white"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
            </div>
          </div>
          <div className="flex-1">
            <h2 className="text-3xl font-black text-white tracking-tight mb-2">{userProfile?.name || 'Automated Bot'}</h2>
            <div className="flex flex-wrap gap-4 text-[10px] font-bold uppercase tracking-widest">
              <span className="text-slate-400 flex items-center gap-1">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                {userProfile?.email || 'user@teslaprime.ai'}
              </span>
              <span className="text-prime-cyan flex items-center gap-1">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                ID: {userProfile?.id || 'USR-XXXX'}
              </span>
              <span className={`flex items-center gap-1 ${userProfile?.kyc === 'verified' ? 'text-emerald-400' : 'text-amber-400'}`}>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                KYC: {userProfile?.kyc?.toUpperCase() || 'PENDING'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sidebar Navigation */}
        <div className="lg:col-span-3 space-y-2">
          {[
            { id: 'overview', label: 'Bot Overview', icon: <><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></> },
            { id: 'marketplace', label: 'Bot Marketplace', icon: <><path d="M3 3v18h18M18 9l-5 5-4-4-3 3"/></> },
            { id: 'profile', label: 'User Profile', icon: <><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></> },
            { id: 'security', label: 'Security & Access', icon: <><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></> },
            { id: 'trading', label: 'Trading Parameters', icon: <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/> },
            { id: 'notifications', label: 'Alert Protocols', icon: <><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></> },
            { id: 'kyc', label: 'KYC Verification', icon: <><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></> }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`w-full flex items-center gap-3 p-4 rounded-2xl transition-all duration-200 text-left group ${
                activeTab === tab.id 
                ? 'bg-prime-cyan text-black shadow-[0_0_20px_rgba(0,240,255,0.2)] scale-100' 
                : 'bg-black/40 border border-white/5 text-slate-400 hover:text-white hover:border-white/20 scale-95 hover:scale-100'
              }`}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                {tab.icon}
              </svg>
              <span className="text-[10px] font-black uppercase tracking-widest">{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Content Area */}
        <div className="lg:col-span-9">
          <div className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-[2rem] p-8 shadow-2xl min-h-[500px]">
            
            {/* Overview Tab */}
            {activeTab === 'overview' && (
              <div className="space-y-8 animate-[fadeIn_0.3s]">
                <div className="flex justify-between items-center border-b border-white/10 pb-4">
                  <h3 className="text-transparent bg-clip-text bg-gradient-to-r from-prime-cyan via-prime-purple to-prime-pink font-black uppercase tracking-widest text-xs">Bot Overview</h3>
                  <div className="flex items-center gap-4">
                    <button 
                        onClick={() => {
                            if (userProfile && onUpdateUser) {
                                onUpdateUser({
                                    ...userProfile,
                                    autoTrading: !userProfile.autoTrading,
                                    activeBots: !userProfile.autoTrading ? (userProfile.activeBots || 1) : 0
                                });
                            }
                        }}
                        className={`px-6 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all shadow-[0_0_15px_rgba(0,0,0,0.2)] ${
                            userProfile?.autoTrading 
                            ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20 hover:bg-rose-500/20 hover:shadow-[0_0_20px_rgba(244,63,94,0.4)]' 
                            : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/20 hover:shadow-[0_0_20px_rgba(16,185,129,0.4)]'
                        }`}
                    >
                        {userProfile?.autoTrading ? 'Halt Trading' : 'Initialize Bot'}
                    </button>
                    <button onClick={() => setActiveTab('trading')} className="px-4 py-2 bg-prime-cyan/10 text-prime-cyan border border-prime-cyan/20 rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-prime-cyan/20 transition-all">
                      Configure Bot
                    </button>
                  </div>
                </div>
                
                <div className="grid lg:grid-cols-2 gap-8 items-start">
                  {/* Left Column - Bot UI Mockup */}
                  <div className="relative">
                      <div className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-2xl relative z-10">
                          {/* Header */}
                          <div className="flex justify-between items-center mb-6 pb-6 border-b border-white/5">
                              <div className="flex items-center gap-3">
                                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${userProfile?.autoTrading ? 'bg-prime-cyan/10 border-prime-cyan/20 text-prime-cyan' : 'bg-slate-800/50 border-slate-700 text-slate-500'}`}>
                                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                                  </div>
                                  <div>
                                      <div className="text-transparent bg-clip-text bg-gradient-to-r from-prime-cyan via-prime-purple to-prime-pink font-bold font-display">Titan Momentum X</div>
                                      {userProfile?.autoTrading ? (
                                          <div className="text-[10px] text-emerald-400 uppercase tracking-widest font-bold flex items-center gap-1">
                                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse-glow"></span> Active ({userProfile.activeBots || 1} Nodes)
                                          </div>
                                      ) : (
                                          <div className="text-[10px] text-slate-500 uppercase tracking-widest font-bold flex items-center gap-1">
                                              <span className="w-1.5 h-1.5 rounded-full bg-slate-500"></span> Offline
                                          </div>
                                      )}
                                  </div>
                              </div>
                              <div className="text-right">
                                  <div className="text-[10px] text-slate-500 uppercase tracking-widest font-bold mb-1">24h Profit</div>
                                  <div className={`text-xl font-mono font-bold ${userProfile?.autoTrading ? 'text-emerald-400' : 'text-slate-500'}`}>
                                      {userProfile?.autoTrading ? '+$1,240.50' : '$0.00'}
                                  </div>
                              </div>
                          </div>

                          {/* Grid Stats */}
                          <div className="grid grid-cols-2 gap-4 mb-6">
                              <div className="bg-white/5 rounded-xl p-4 border border-white/5">
                                  <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-2">Win Rate</div>
                                  <div className="flex items-end gap-2">
                                      <div className={`text-2xl font-mono font-bold ${userProfile?.autoTrading ? 'text-white' : 'text-slate-600'}`}>
                                          {userProfile?.autoTrading ? '78.4%' : '0.0%'}
                                      </div>
                                      {userProfile?.autoTrading && <div className="text-[10px] text-emerald-400 font-mono mb-1">+2.1%</div>}
                                  </div>
                              </div>
                              <div className="bg-white/5 rounded-xl p-4 border border-white/5">
                                  <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-2">Active Pairs</div>
                                  <div className="flex gap-2 mt-2">
                                      {userProfile?.autoTrading ? (
                                          <>
                                              <span className="px-2 py-1 bg-white/10 rounded text-[10px] font-mono text-white">TSLA/USD</span>
                                              <span className="px-2 py-1 bg-white/10 rounded text-[10px] font-mono text-white">BTC/USD</span>
                                          </>
                                      ) : (
                                          <span className="px-2 py-1 bg-white/5 rounded text-[10px] font-mono text-slate-600">NONE</span>
                                      )}
                                  </div>
                              </div>
                          </div>

                          {/* Live Trade Feed */}
                          <div>
                              <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-4">Live Execution Feed</div>
                              <div className="space-y-2">
                                  {userProfile?.autoTrading ? (
                                      [
                                          { pair: 'TSLA/USD', type: 'BUY', price: '175.40', time: '2s ago', profit: null },
                                          { pair: 'BTC/USD', type: 'SELL', price: '68,450', time: '14s ago', profit: '+$45.20' },
                                          { pair: 'TSLA/USD', type: 'SELL', price: '176.10', time: '45s ago', profit: '+$12.50' }
                                      ].map((trade, i) => (
                                          <div key={i} className="flex justify-between items-center p-3 rounded-lg bg-white/[0.02] border border-white/5">
                                              <div className="flex items-center gap-3">
                                                  <div className={`text-[9px] font-black uppercase tracking-widest px-2 py-1 rounded ${trade.type === 'BUY' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
                                                      {trade.type}
                                                  </div>
                                                  <div className="font-mono text-xs text-white">{trade.pair}</div>
                                              </div>
                                              <div className="text-right">
                                                  <div className="font-mono text-xs text-slate-300">{trade.price}</div>
                                                  {trade.profit ? (
                                                      <div className="text-[9px] font-mono text-emerald-400">{trade.profit}</div>
                                                  ) : (
                                                      <div className="text-[9px] text-slate-500">{trade.time}</div>
                                                  )}
                                              </div>
                                          </div>
                                      ))
                                  ) : (
                                      <div className="p-6 text-center border border-white/5 rounded-lg bg-white/[0.02]">
                                          <div className="text-[10px] text-slate-500 font-mono uppercase tracking-widest">System Offline. Awaiting Activation.</div>
                                      </div>
                                  )}
                              </div>
                          </div>
                      </div>
                      
                      {/* Glow */}
                      <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full blur-[80px] rounded-full pointer-events-none -z-10 transition-colors duration-1000 ${userProfile?.autoTrading ? 'bg-prime-cyan/10' : 'bg-transparent'}`}></div>
                  </div>

                  {/* Right Column - Content */}
                  <div>
                      <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/10 bg-white/5 mb-6">
                          <span className="text-[9px] font-bold text-prime-cyan uppercase tracking-widest">Algorithmic Trading</span>
                      </div>
                      
                      <h2 className="text-2xl font-black text-white tracking-tighter mb-4">
                          AI Bot Trading <br/>
                          <span className="text-transparent bg-clip-text bg-gradient-to-r from-prime-cyan to-blue-500">Automation</span>
                      </h2>
                      
                      <p className="text-slate-400 text-sm leading-relaxed mb-6">
                          Deploy institutional-grade trading algorithms that operate 24/7. Our neural networks analyze millions of data points to execute high-probability trades with zero emotional interference.
                      </p>

                      <ul className="space-y-3 mb-8">
                          {[
                              'High-frequency execution capabilities',
                              'Dynamic risk management protocols',
                              'Pre-configured strategy templates',
                              'Real-time performance analytics'
                          ].map((benefit, i) => (
                              <li key={i} className="flex items-center gap-3 text-xs text-slate-300 font-medium">
                                  <span className="w-4 h-4 rounded-full bg-prime-cyan/10 flex items-center justify-center text-prime-cyan border border-prime-cyan/20">
                                      <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M20 6L9 17l-5-5"/></svg>
                                  </span>
                                  {benefit}
                              </li>
                          ))}
                      </ul>

                      {/* Strategy Selection */}
                      <div className="mb-8">
                          <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-2 block">Algorithmic Strategy</label>
                          <div className="relative">
                              <select 
                                  className="w-full bg-black/60 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-prime-cyan outline-none transition-all appearance-none cursor-pointer"
                                  defaultValue="momentum"
                                  disabled={userProfile?.autoTrading}
                              >
                                  <option value="momentum">Titan Momentum X (Aggressive)</option>
                                  <option value="mean_reversion">Aegis Mean Reversion (Conservative)</option>
                                  <option value="arbitrage">Quantum Arbitrage (Neutral)</option>
                                  <option value="grid">Grid Scalper Pro (Balanced)</option>
                              </select>
                              <div className="absolute inset-y-0 right-4 flex items-center pointer-events-none text-slate-400">
                                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="m6 9 6 6 6-6"/></svg>
                              </div>
                          </div>
                          {userProfile?.autoTrading && (
                              <p className="text-[9px] text-rose-400 mt-2 font-bold uppercase tracking-widest">Halt trading to change strategy</p>
                          )}
                      </div>

                      {/* Bot Activity Log */}
                      <div className="bg-black/40 border border-white/5 rounded-2xl p-4 h-[180px] overflow-y-auto font-mono text-xs">
                          <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-3 sticky top-0 bg-black/80 backdrop-blur-sm py-1">System Log</div>
                          {userProfile?.autoTrading ? (
                              <div className="space-y-2">
                                  <div className="flex gap-3 text-slate-400">
                                      <span className="text-prime-cyan">[{new Date().toLocaleTimeString()}]</span>
                                      <span>Scanning market conditions...</span>
                                  </div>
                                  <div className="flex gap-3 text-slate-400">
                                      <span className="text-prime-cyan">[{new Date(Date.now() - 5000).toLocaleTimeString()}]</span>
                                      <span>Analyzing TSLA order book depth.</span>
                                  </div>
                                  <div className="flex gap-3 text-slate-400">
                                      <span className="text-prime-cyan">[{new Date(Date.now() - 15000).toLocaleTimeString()}]</span>
                                      <span className="text-emerald-400">Executed BUY TSLA @ 175.40</span>
                                  </div>
                                  <div className="flex gap-3 text-slate-400">
                                      <span className="text-prime-cyan">[{new Date(Date.now() - 45000).toLocaleTimeString()}]</span>
                                      <span>Neural net confidence score: 89.4%</span>
                                  </div>
                                  <div className="flex gap-3 text-slate-400">
                                      <span className="text-prime-cyan">[{new Date(Date.now() - 60000).toLocaleTimeString()}]</span>
                                      <span className="text-emerald-400">Bot Initialized. Strategy: Momentum X.</span>
                                  </div>
                              </div>
                          ) : (
                              <div className="flex items-center justify-center h-full text-slate-600">
                                  System Offline. Waiting for initialization.
                              </div>
                          )}
                      </div>
                  </div>
                </div>
              </div>
            )}

            {/* Marketplace Tab */}
            {activeTab === 'marketplace' && (
              <div className="animate-[fadeIn_0.3s]">
                <Marketplace />
              </div>
            )}

            {/* Automated Bot Tab */}
            {activeTab === 'profile' && (
              <div className="space-y-8 animate-[fadeIn_0.3s]">
                <h3 className="text-white font-black uppercase tracking-widest text-xs border-b border-white/10 pb-4">User Profile Configuration</h3>
                <form 
                  onSubmit={(e) => {
                    e.preventDefault();
                    const formData = new FormData(e.currentTarget);
                    if (userProfile && onUpdateUser) {
                      onUpdateUser({
                        ...userProfile,
                        name: formData.get('name') as string,
                        phoneNumber: formData.get('phone') as string,
                        country: formData.get('country') as string,
                      });
                    }
                  }}
                  className="space-y-8"
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Full Name</label>
                      <input name="name" type="text" defaultValue={userProfile?.name} className="w-full bg-black/60 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-prime-cyan outline-none transition-all" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Email Address</label>
                      <input type="email" defaultValue={userProfile?.email} disabled className="w-full bg-black/40 border border-white/5 rounded-xl px-4 py-3 text-sm text-slate-500 cursor-not-allowed" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Phone Number</label>
                      <input name="phone" type="tel" defaultValue={userProfile?.phoneNumber} className="w-full bg-black/60 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-prime-cyan outline-none transition-all" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Country</label>
                      <input name="country" type="text" defaultValue={userProfile?.country} className="w-full bg-black/60 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-prime-cyan outline-none transition-all" />
                    </div>
                  </div>
                  <div className="pt-6 border-t border-white/10 flex justify-end">
                    <button type="submit" className="px-6 py-3 bg-prime-cyan text-black rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-white transition-all shadow-[0_0_20px_rgba(0,240,255,0.3)]">Save Changes</button>
                  </div>
                </form>
              </div>
            )}

            {/* Security Tab */}
            {activeTab === 'security' && (
              <div className="space-y-8 animate-[fadeIn_0.3s]">
                <h3 className="text-white font-black uppercase tracking-widest text-xs border-b border-white/10 pb-4">Security Protocols</h3>
                
                <div className="space-y-6">
                  <div className="flex items-center justify-between p-4 bg-black/60 border border-white/10 rounded-2xl">
                    <div>
                      <div className="text-sm font-bold text-white mb-1">Two-Factor Authentication (2FA)</div>
                      <div className="text-[10px] text-slate-500 uppercase tracking-widest">Secure your account with an authenticator app</div>
                    </div>
                    <button 
                        onClick={() => setConfirmModal({
                            isOpen: true,
                            title: 'Enable 2FA',
                            message: 'Are you sure you want to enable Two-Factor Authentication? You will need an authenticator app like Google Authenticator.',
                            type: 'info',
                            onConfirm: () => console.log('2FA Enabled')
                        })}
                        className="px-4 py-2 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-emerald-500/20 transition-all"
                    >
                        Enable
                    </button>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-black/60 border border-white/10 rounded-2xl">
                    <div>
                      <div className="text-sm font-bold text-white mb-1">Change Password</div>
                      <div className="text-[10px] text-slate-500 uppercase tracking-widest">Last changed 30 days ago</div>
                    </div>
                    <button 
                        onClick={() => setConfirmModal({
                            isOpen: true,
                            title: 'Change Password',
                            message: 'You will receive an email with instructions to reset your password. Do you want to proceed?',
                            type: 'warning',
                            onConfirm: async () => {
                                if (userProfile?.email) {
                                    try {
                                        await sendPasswordResetEmail(auth, userProfile.email);
                                        alert('Password reset email sent! Please check your inbox.');
                                    } catch (error) {
                                        console.error('Failed to send password reset email:', error);
                                        alert('Failed to send password reset email. Please try again later.');
                                    }
                                }
                            }
                        })}
                        className="px-4 py-2 bg-white/5 text-white border border-white/10 rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-white/10 transition-all"
                    >
                        Update
                    </button>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-black/60 border border-white/10 rounded-2xl">
                    <div>
                      <div className="text-sm font-bold text-white mb-1">Active Sessions</div>
                      <div className="text-[10px] text-slate-500 uppercase tracking-widest">Manage devices logged into your account</div>
                    </div>
                    <button 
                        onClick={() => setConfirmModal({
                            isOpen: true,
                            title: 'Revoke All Sessions',
                            message: 'This will log you out of all other devices immediately. Are you sure?',
                            type: 'danger',
                            onConfirm: async () => {
                                try {
                                    await auth.signOut();
                                } catch (error) {
                                    console.error('Failed to sign out:', error);
                                }
                            }
                        })}
                        className="px-4 py-2 bg-rose-500/10 text-rose-400 border border-rose-500/20 rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-rose-500/20 transition-all"
                    >
                        Revoke All
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Trading Tab */}
            {activeTab === 'trading' && (
              <div className="space-y-8 animate-[fadeIn_0.3s]">
                <h3 className="text-white font-black uppercase tracking-widest text-xs border-b border-white/10 pb-4">Algorithmic Parameters</h3>
                
                <div className="space-y-8">
                  <div className="space-y-4">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Risk Tolerance Level</label>
                    <div className="grid grid-cols-3 gap-4">
                      {['conservative', 'balanced', 'aggressive'].map((level) => (
                        <button
                          key={level}
                          onClick={() => handleSettingChange('riskLevel', level)}
                          className={`p-4 rounded-xl border transition-all flex flex-col items-center justify-center gap-2 ${
                            settings.riskLevel === level
                            ? 'bg-prime-cyan/10 border-prime-cyan text-prime-cyan shadow-[0_0_15px_rgba(0,240,255,0.2)]'
                            : 'bg-black/60 border-white/10 text-slate-500 hover:border-white/30 hover:text-white'
                          }`}
                        >
                          <span className="text-[10px] font-black uppercase tracking-widest">{level}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Maximum Trade Size (USDT)</label>
                      <span className="text-prime-cyan font-mono font-bold">${settings.maxTradeSize.toLocaleString()}</span>
                    </div>
                    <input 
                      type="range" 
                      min="100" 
                      max="10000" 
                      step="100"
                      value={settings.maxTradeSize}
                      onChange={(e) => handleSettingChange('maxTradeSize', parseInt(e.target.value))}
                      className="w-full h-2 bg-black/60 rounded-lg appearance-none cursor-pointer accent-prime-cyan"
                    />
                    <div className="flex justify-between text-[9px] text-slate-600 font-mono">
                      <span>$100</span>
                      <span>$10,000</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Notifications Tab */}
            {activeTab === 'notifications' && (
              <div className="space-y-8 animate-[fadeIn_0.3s]">
                <h3 className="text-white font-black uppercase tracking-widest text-xs border-b border-white/10 pb-4">Alert Protocols</h3>
                
                <div className="space-y-4">
                  {[
                    { key: 'tradeExecutions', label: 'Trade Executions', desc: 'Real-time alerts when algorithms open or close positions' },
                    { key: 'dailySummary', label: 'Daily Performance Summary', desc: 'End-of-day report on P/L and portfolio metrics' },
                    { key: 'marketNews', label: 'Market Intelligence', desc: 'High-impact news and volatility alerts' }
                  ].map((item) => (
                    <div key={item.key} className="flex items-center justify-between p-4 bg-black/60 border border-white/10 rounded-2xl cursor-pointer hover:border-white/20 transition-all" onClick={() => handleNotificationChange(item.key as keyof TradingSettings['notifications'], !settings.notifications[item.key as keyof TradingSettings['notifications']])}>
                      <div>
                        <div className="text-sm font-bold text-white mb-1">{item.label}</div>
                        <div className="text-[10px] text-slate-500 uppercase tracking-widest">{item.desc}</div>
                      </div>
                      <div className={`w-12 h-6 rounded-full p-1 transition-colors duration-300 ease-in-out ${settings.notifications[item.key as keyof TradingSettings['notifications']] ? 'bg-prime-cyan' : 'bg-white/10'}`}>
                        <div className={`w-4 h-4 rounded-full bg-white shadow-md transform transition-transform duration-300 ease-in-out ${settings.notifications[item.key as keyof TradingSettings['notifications']] ? 'translate-x-6' : 'translate-x-0'}`}></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* KYC Tab */}
            {activeTab === 'kyc' && (
              <div className="space-y-8 animate-[fadeIn_0.3s]">
                <h3 className="text-white font-black uppercase tracking-widest text-xs border-b border-white/10 pb-4">KYC Verification</h3>
                
                <div className="space-y-6">
                  <div className="p-6 bg-black/60 border border-white/10 rounded-2xl">
                    <div className="flex items-center justify-between mb-6">
                      <div>
                        <h4 className="text-white font-bold mb-1">Identity Verification</h4>
                        <p className="text-slate-400 text-sm">Upload a government-issued ID to unlock full trading capabilities.</p>
                      </div>
                      <div className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-widest ${
                        userProfile?.kyc === 'verified' ? 'bg-emerald-500/20 text-emerald-400' :
                        userProfile?.kyc === 'pending' ? 'bg-amber-500/20 text-amber-400' :
                        'bg-rose-500/20 text-rose-400'
                      }`}>
                        {userProfile?.kyc || 'Unverified'}
                      </div>
                    </div>

                    {userProfile?.kyc === 'verified' ? (
                      <div className="flex items-center gap-4 p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-400">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                        <div>
                          <p className="font-bold">Identity Verified</p>
                          <p className="text-xs opacity-80">Your account has full access to all platform features.</p>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="border-2 border-dashed border-white/20 rounded-2xl p-8 text-center hover:border-prime-cyan/50 transition-colors relative group">
                          <input 
                            type="file" 
                            accept="image/*,.pdf"
                            onChange={handleFileUpload}
                            disabled={uploading || userProfile?.kyc === 'pending'}
                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
                          />
                          <div className="flex flex-col items-center gap-3">
                            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-400 group-hover:text-prime-cyan transition-colors"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                            <div>
                              <p className="text-white font-bold">Click to upload or drag and drop</p>
                              <p className="text-slate-500 text-xs mt-1">SVG, PNG, JPG or PDF (max. 5MB)</p>
                            </div>
                          </div>
                        </div>

                        {uploading && (
                          <div className="space-y-2">
                            <div className="flex justify-between text-xs text-slate-400">
                              <span>Uploading document...</span>
                              <span>{Math.round(uploadProgress)}%</span>
                            </div>
                            <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                              <div 
                                className="h-full bg-prime-cyan transition-all duration-300"
                                style={{ width: `${uploadProgress}%` }}
                              ></div>
                            </div>
                          </div>
                        )}

                        {uploadError && (
                          <p className="text-rose-400 text-xs">{uploadError}</p>
                        )}
                        
                        {userProfile?.kyc === 'pending' && !uploading && (
                          <div className="flex items-center gap-3 p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-400">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                            <p className="text-xs">Your document is under review. This usually takes 1-2 business days.</p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

          </div>
        </div>
      </div>
      
      <ConfirmationModal 
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        type={confirmModal.type}
      />
    </div>
  );
};
