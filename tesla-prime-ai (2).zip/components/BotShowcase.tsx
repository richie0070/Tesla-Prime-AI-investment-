import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';

interface BotShowcaseProps {
    onDeploy: () => void;
}

interface BotData {
    id: string;
    name: string;
    type: string;
    status: 'Active' | 'Idle' | 'Training';
    profit24h: string;
    winRate: string;
    winRateChange: string;
    activePairs: string[];
    description: string;
    chartData: any[];
    liveTrades: any[];
    color: string;
}

const BOTS_DATA: BotData[] = [
    {
        id: 'titan',
        name: 'Titan Momentum X',
        type: 'Trend Following',
        status: 'Active',
        profit24h: '+$1,240.50',
        winRate: '78.4%',
        winRateChange: '+2.1%',
        activePairs: ['TSLA/USD', 'BTC/USD'],
        description: 'Capitalizes on strong directional price movements across major equities and crypto assets. Utilizes advanced moving average crossovers and volume confirmation.',
        color: 'emerald',
        chartData: Array.from({ length: 24 }, (_, i) => ({ time: `${i}:00`, value: 10000 + Math.random() * 2000 + (i * 100) })),
        liveTrades: [
            { pair: 'TSLA/USD', type: 'BUY', price: '175.40', time: '2s ago', profit: null },
            { pair: 'BTC/USD', type: 'SELL', price: '68,450', time: '14s ago', profit: '+$45.20' },
            { pair: 'TSLA/USD', type: 'SELL', price: '176.10', time: '45s ago', profit: '+$12.50' }
        ]
    },
    {
        id: 'aegis',
        name: 'Aegis Mean Reversion',
        type: 'Statistical Arbitrage',
        status: 'Active',
        profit24h: '+$845.20',
        winRate: '82.1%',
        winRateChange: '+0.5%',
        activePairs: ['EUR/USD', 'ETH/USD'],
        description: 'Identifies overbought and oversold conditions using Bollinger Bands and RSI. Executes rapid counter-trend trades with tight stop-losses.',
        color: 'blue',
        chartData: Array.from({ length: 24 }, (_, i) => ({ time: `${i}:00`, value: 5000 + Math.sin(i) * 500 + (i * 50) })),
        liveTrades: [
            { pair: 'EUR/USD', type: 'BUY', price: '1.0845', time: '5s ago', profit: null },
            { pair: 'ETH/USD', type: 'BUY', price: '3,450', time: '22s ago', profit: '+$18.40' },
            { pair: 'EUR/USD', type: 'SELL', price: '1.0850', time: '1m ago', profit: '+$5.00' }
        ]
    },
    {
        id: 'quantum',
        name: 'Quantum Arbitrage',
        type: 'High-Frequency',
        status: 'Idle',
        profit24h: '+$3,102.00',
        winRate: '94.5%',
        winRateChange: '-0.2%',
        activePairs: ['BTC/USDT', 'ETH/BTC'],
        description: 'Exploits micro-inefficiencies across multiple exchanges simultaneously. Requires significant capital allocation for optimal execution speed.',
        color: 'purple',
        chartData: Array.from({ length: 24 }, (_, i) => ({ time: `${i}:00`, value: 20000 + Math.random() * 500 + (i * 200) })),
        liveTrades: [
            { pair: 'BTC/USDT', type: 'BUY', price: '68,400', time: '1s ago', profit: null },
            { pair: 'ETH/BTC', type: 'SELL', price: '0.0504', time: '2s ago', profit: '+$2.10' },
            { pair: 'BTC/USDT', type: 'SELL', price: '68,405', time: '3s ago', profit: '+$4.50' }
        ]
    }
];

const BotShowcase: React.FC<BotShowcaseProps> = ({ onDeploy }) => {
  const [selectedBot, setSelectedBot] = useState<BotData>(BOTS_DATA[0]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'performance' | 'live'>('overview');

  // Simulate live data updates
  const [liveChartData, setLiveChartData] = useState(selectedBot.chartData);
  
  useEffect(() => {
      setLiveChartData(selectedBot.chartData);
  }, [selectedBot]);

  useEffect(() => {
      if (!isModalOpen || activeTab !== 'live') return;
      
      const interval = setInterval(() => {
          setLiveChartData(prev => {
              const newData = [...prev.slice(1)];
              const lastVal = prev[prev.length - 1].value;
              const change = (Math.random() - 0.5) * (selectedBot.id === 'quantum' ? 50 : 200);
              newData.push({
                  time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
                  value: lastVal + change
              });
              return newData;
          });
      }, 2000);
      
      return () => clearInterval(interval);
  }, [isModalOpen, activeTab, selectedBot]);

  const getColorClass = (color: string, type: 'text' | 'bg' | 'border') => {
      const map: Record<string, Record<string, string>> = {
          emerald: { text: 'text-emerald-400', bg: 'bg-emerald-500', border: 'border-emerald-500/30' },
          blue: { text: 'text-blue-400', bg: 'bg-blue-500', border: 'border-blue-500/30' },
          purple: { text: 'text-purple-400', bg: 'bg-purple-500', border: 'border-purple-500/30' },
      };
      return map[color]?.[type] || map.emerald[type];
  };

  return (
    <section id="ai-trading" className="py-24 md:py-32 px-6 relative border-t border-white/5 bg-transparent overflow-hidden">
        <div className="max-w-7xl mx-auto relative z-10 grid lg:grid-cols-2 gap-16 items-center">
            
            {/* Left Column - Interactive Bot Selection */}
            <div className="relative order-2 lg:order-1">
                <div className="space-y-4 relative z-10">
                    {BOTS_DATA.map((bot) => (
                        <div 
                            key={bot.id}
                            onClick={() => { setSelectedBot(bot); setIsModalOpen(true); }}
                            className={`bg-black/40 backdrop-blur-xl border rounded-[1.5rem] p-5 cursor-pointer transition-all duration-300 group hover:-translate-y-1 ${selectedBot.id === bot.id ? `border-${bot.color}-500/50 shadow-[0_0_30px_rgba(0,0,0,0.5)]` : 'border-white/10 hover:border-white/30'}`}
                            style={{ boxShadow: selectedBot.id === bot.id ? `0 0 30px var(--color-${bot.color}-500, rgba(16, 185, 129, 0.1))` : 'none' }}
                        >
                            <div className="flex justify-between items-start mb-4">
                                <div className="flex items-center gap-4">
                                    <div className={`w-12 h-12 rounded-xl bg-${bot.color}-500/10 border border-${bot.color}-500/20 flex items-center justify-center ${getColorClass(bot.color, 'text')}`}>
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                                    </div>
                                    <div>
                                        <div className="text-white font-bold font-display text-lg group-hover:text-prime-cyan transition-colors">{bot.name}</div>
                                        <div className="text-[10px] text-slate-400 uppercase tracking-widest font-bold">{bot.type}</div>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <div className={`text-[10px] uppercase tracking-widest font-bold flex items-center justify-end gap-1.5 mb-1 ${bot.status === 'Active' ? getColorClass(bot.color, 'text') : 'text-slate-500'}`}>
                                        <span className={`w-1.5 h-1.5 rounded-full ${bot.status === 'Active' ? `${getColorClass(bot.color, 'bg')} animate-pulse-glow` : 'bg-slate-500'}`}></span> 
                                        {bot.status}
                                    </div>
                                    <div className="text-sm font-mono text-white font-bold">{bot.profit24h}</div>
                                </div>
                            </div>
                            
                            <div className="flex items-center justify-between text-xs">
                                <div className="flex gap-2">
                                    {bot.activePairs.map(pair => (
                                        <span key={pair} className="px-2 py-1 bg-white/5 rounded font-mono text-slate-300 border border-white/5">{pair}</span>
                                    ))}
                                </div>
                                <div className="flex items-center gap-2 text-slate-400 font-mono">
                                    Win Rate: <span className="text-white">{bot.winRate}</span>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
                
                {/* Glow */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-blue-500/10 blur-[100px] rounded-full pointer-events-none -z-10"></div>
            </div>

            {/* Right Column - Content */}
            <div className="order-1 lg:order-2">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/10 bg-white/5 mb-6">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Algorithmic Trading</span>
                </div>
                
                <h2 className="text-4xl md:text-5xl font-black text-white tracking-tighter mb-6">
                    AI Bot Trading <br/>
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-prime-cyan to-blue-500">Automation</span>
                </h2>
                
                <p className="text-slate-400 text-lg leading-relaxed mb-8">
                    Deploy institutional-grade trading algorithms that operate 24/7. Our neural networks analyze millions of data points to execute high-probability trades with zero emotional interference. Click on any bot to view deep analytics.
                </p>

                <ul className="space-y-4 mb-10">
                    {[
                        'High-frequency execution capabilities',
                        'Dynamic risk management protocols',
                        'Pre-configured strategy templates',
                        'Real-time performance analytics'
                    ].map((benefit, i) => (
                        <li key={i} className="flex items-center gap-3 text-sm text-slate-300 font-medium">
                            <span className="w-5 h-5 rounded-full bg-prime-cyan/10 flex items-center justify-center text-prime-cyan border border-prime-cyan/20">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M20 6L9 17l-5-5"/></svg>
                            </span>
                            {benefit}
                        </li>
                    ))}
                </ul>

                <button 
                    onClick={onDeploy}
                    className="px-8 py-4 bg-white text-black hover:bg-prime-cyan font-black text-xs rounded-full shadow-[0_0_30px_rgba(255,255,255,0.1)] transition-all hover:-translate-y-1 uppercase tracking-[0.2em]"
                >
                    Explore Trading Bots
                </button>
            </div>

        </div>

        {/* Detailed Bot Modal */}
        <AnimatePresence>
            {isModalOpen && (
                <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 md:p-6">
                    <motion.div 
                        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                        className="absolute inset-0 bg-black/90 backdrop-blur-xl" 
                        onClick={() => setIsModalOpen(false)}
                    />
                    
                    <motion.div 
                        initial={{ opacity: 0, scale: 0.95, y: 20 }} 
                        animate={{ opacity: 1, scale: 1, y: 0 }} 
                        exit={{ opacity: 0, scale: 0.95, y: 20 }}
                        className="relative w-full max-w-4xl bg-[#0a0a0a] border border-white/10 rounded-[2rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
                    >
                        {/* Modal Header */}
                        <div className="p-6 md:p-8 border-b border-white/5 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 bg-white/[0.02]">
                            <div className="flex items-center gap-5">
                                <div className={`w-16 h-16 rounded-2xl bg-${selectedBot.color}-500/10 border border-${selectedBot.color}-500/30 flex items-center justify-center ${getColorClass(selectedBot.color, 'text')} shadow-[0_0_30px_rgba(0,0,0,0.5)]`} style={{ boxShadow: `0 0 30px var(--color-${selectedBot.color}-500, rgba(16, 185, 129, 0.2))` }}>
                                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                                </div>
                                <div>
                                    <h3 className="text-2xl md:text-3xl font-black text-white font-display tracking-tight">{selectedBot.name}</h3>
                                    <div className="flex items-center gap-3 mt-1">
                                        <span className="text-xs text-slate-400 uppercase tracking-widest font-bold">{selectedBot.type}</span>
                                        <span className="w-1 h-1 rounded-full bg-white/20"></span>
                                        <div className={`text-[10px] uppercase tracking-widest font-bold flex items-center gap-1.5 ${selectedBot.status === 'Active' ? getColorClass(selectedBot.color, 'text') : 'text-slate-500'}`}>
                                            <span className={`w-1.5 h-1.5 rounded-full ${selectedBot.status === 'Active' ? `${getColorClass(selectedBot.color, 'bg')} animate-pulse-glow` : 'bg-slate-500'}`}></span> 
                                            {selectedBot.status}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="flex gap-2 bg-black/50 p-1 rounded-xl border border-white/5">
                                {['overview', 'performance', 'live'].map((tab) => (
                                    <button 
                                        key={tab}
                                        onClick={() => setActiveTab(tab as any)}
                                        className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === tab ? 'bg-white/10 text-white shadow-md' : 'text-slate-500 hover:text-slate-300'}`}
                                    >
                                        {tab}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Modal Body */}
                        <div className="p-6 md:p-8 overflow-y-auto flex-1 custom-scrollbar">
                            
                            {activeTab === 'overview' && (
                                <div className="space-y-8 animate-[fadeIn_0.3s]">
                                    <p className="text-slate-300 leading-relaxed text-sm md:text-base">
                                        {selectedBot.description}
                                    </p>
                                    
                                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                        <div className="bg-white/5 rounded-xl p-5 border border-white/5">
                                            <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-2">24h Profit</div>
                                            <div className={`text-2xl font-mono font-bold ${getColorClass(selectedBot.color, 'text')}`}>{selectedBot.profit24h}</div>
                                        </div>
                                        <div className="bg-white/5 rounded-xl p-5 border border-white/5">
                                            <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-2">Win Rate</div>
                                            <div className="flex items-end gap-2">
                                                <div className="text-2xl font-mono text-white font-bold">{selectedBot.winRate}</div>
                                                <div className={`text-xs font-mono mb-1 ${selectedBot.winRateChange.startsWith('+') ? 'text-emerald-400' : 'text-rose-400'}`}>{selectedBot.winRateChange}</div>
                                            </div>
                                        </div>
                                        <div className="bg-white/5 rounded-xl p-5 border border-white/5">
                                            <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-2">Active Pairs</div>
                                            <div className="text-lg font-mono text-white font-bold">{selectedBot.activePairs.length}</div>
                                        </div>
                                        <div className="bg-white/5 rounded-xl p-5 border border-white/5">
                                            <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-2">Risk Level</div>
                                            <div className="text-lg font-mono text-white font-bold capitalize">{selectedBot.id === 'titan' ? 'Balanced' : selectedBot.id === 'quantum' ? 'Aggressive' : 'Conservative'}</div>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {activeTab === 'performance' && (
                                <div className="space-y-6 animate-[fadeIn_0.3s]">
                                    <div className="flex justify-between items-center">
                                        <h4 className="text-xs font-bold text-white uppercase tracking-widest">Equity Curve (24h)</h4>
                                        <div className="text-[10px] text-slate-500 font-mono">Simulated Data</div>
                                    </div>
                                    <div className="h-[300px] w-full bg-black/20 rounded-xl border border-white/5 p-4">
                                        <ResponsiveContainer width="100%" height="100%">
                                            <AreaChart data={selectedBot.chartData}>
                                                <defs>
                                                    <linearGradient id={`color${selectedBot.id}`} x1="0" y1="0" x2="0" y2="1">
                                                        <stop offset="5%" stopColor={selectedBot.color === 'emerald' ? '#10b981' : selectedBot.color === 'blue' ? '#3b82f6' : '#a855f7'} stopOpacity={0.3}/>
                                                        <stop offset="95%" stopColor={selectedBot.color === 'emerald' ? '#10b981' : selectedBot.color === 'blue' ? '#3b82f6' : '#a855f7'} stopOpacity={0}/>
                                                    </linearGradient>
                                                </defs>
                                                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                                                <XAxis dataKey="time" stroke="rgba(255,255,255,0.2)" fontSize={10} tickLine={false} axisLine={false} />
                                                <YAxis stroke="rgba(255,255,255,0.2)" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(val) => `$${(val/1000).toFixed(1)}k`} />
                                                <Tooltip 
                                                    contentStyle={{ backgroundColor: '#000', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '8px', fontSize: '12px', fontFamily: 'monospace' }}
                                                    itemStyle={{ color: '#fff' }}
                                                />
                                                <Area type="monotone" dataKey="value" stroke={selectedBot.color === 'emerald' ? '#10b981' : selectedBot.color === 'blue' ? '#3b82f6' : '#a855f7'} strokeWidth={2} fillOpacity={1} fill={`url(#color${selectedBot.id})`} />
                                            </AreaChart>
                                        </ResponsiveContainer>
                                    </div>
                                </div>
                            )}

                            {activeTab === 'live' && (
                                <div className="grid md:grid-cols-2 gap-8 animate-[fadeIn_0.3s]">
                                    <div className="space-y-4">
                                        <div className="flex justify-between items-center mb-2">
                                            <h4 className="text-xs font-bold text-white uppercase tracking-widest flex items-center gap-2">
                                                <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
                                                Live Execution Feed
                                            </h4>
                                        </div>
                                        <div className="space-y-3">
                                            {selectedBot.liveTrades.map((trade, i) => (
                                                <div key={i} className="flex justify-between items-center p-4 rounded-xl bg-white/[0.02] border border-white/5 hover:bg-white/[0.04] transition-colors">
                                                    <div className="flex items-center gap-4">
                                                        <div className={`text-[10px] font-black uppercase tracking-widest px-2.5 py-1.5 rounded-md ${trade.type === 'BUY' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'}`}>
                                                            {trade.type}
                                                        </div>
                                                        <div className="font-mono text-sm text-white font-bold">{trade.pair}</div>
                                                    </div>
                                                    <div className="text-right">
                                                        <div className="font-mono text-sm text-slate-300">{trade.price}</div>
                                                        {trade.profit ? (
                                                            <div className="text-[10px] font-mono text-emerald-400 font-bold">{trade.profit}</div>
                                                        ) : (
                                                            <div className="text-[10px] text-slate-500 font-mono">{trade.time}</div>
                                                        )}
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                    
                                    <div className="space-y-4">
                                        <h4 className="text-xs font-bold text-white uppercase tracking-widest">Real-Time Micro-Chart</h4>
                                        <div className="h-[250px] w-full bg-black/20 rounded-xl border border-white/5 p-4 relative overflow-hidden">
                                            <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:20px_20px] [mask-image:radial-gradient(ellipse_at_center,black,transparent_80%)]"></div>
                                            <ResponsiveContainer width="100%" height="100%">
                                                <LineChart data={liveChartData}>
                                                    <Line type="stepAfter" dataKey="value" stroke={selectedBot.color === 'emerald' ? '#10b981' : selectedBot.color === 'blue' ? '#3b82f6' : '#a855f7'} strokeWidth={2} dot={false} isAnimationActive={false} />
                                                    <YAxis domain={['auto', 'auto']} hide />
                                                </LineChart>
                                            </ResponsiveContainer>
                                        </div>
                                    </div>
                                </div>
                            )}

                        </div>

                        {/* Modal Footer */}
                        <div className="p-6 border-t border-white/5 bg-black/50 flex justify-end gap-4">
                            <button onClick={() => setIsModalOpen(false)} className="px-6 py-3 rounded-xl text-xs font-bold text-slate-400 hover:text-white uppercase tracking-widest transition-colors">
                                Close
                            </button>
                            <button onClick={() => { setIsModalOpen(false); onDeploy(); }} className={`px-8 py-3 rounded-xl text-xs font-black text-black uppercase tracking-widest transition-all shadow-lg hover:-translate-y-0.5 ${getColorClass(selectedBot.color, 'bg')} hover:opacity-90`}>
                                Deploy Strategy
                            </button>
                        </div>
                        
                        {/* Close Button (X) */}
                        <button onClick={() => setIsModalOpen(false)} className="absolute top-6 right-6 text-slate-500 hover:text-white transition-colors bg-black/50 p-2 rounded-full border border-white/10">
                            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                        </button>
                    </motion.div>
                </div>
            )}
        </AnimatePresence>
    </section>
  );
};

export default BotShowcase;