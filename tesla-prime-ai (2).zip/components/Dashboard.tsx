import React, { useEffect, useState, useMemo } from 'react';
import { TradingStats, TradingSettings, User, Transaction } from '../types';
import { AreaChart, Area, ResponsiveContainer, YAxis, XAxis, Tooltip, CartesianGrid } from 'recharts';
import NewsFeed from './NewsFeed';
import LiveBroker from './LiveBroker';
import { SettingsPanel } from './SettingsPanel';

import { LocalMLWidget } from './LocalMLWidget';
import Marketplace from './Marketplace';
import Liquidity from './Liquidity';
import Intel from './Intel';
import Portfolio from './Portfolio';
import MarketView from './MarketView';
import RealEstateDashboard from './RealEstateDashboard';
import { TickerTape, MarketOverview } from 'react-ts-tradingview-widgets';

interface DashboardProps {
  stats: TradingStats;
  userProfile?: User;
  settings: TradingSettings;
  onUpdateSettings: (settings: TradingSettings) => void;
  onOpenDepositModal?: () => void;
  onOpenWithdrawModal?: () => void;
  activePage: string;
  onNavigate: (page: string) => void;
  transactions?: Transaction[];
  onUpdateUser?: (user: User) => void;
}

const MARKETS_DATA_BASE = [
  { symbol: 'TSLA', name: 'Tesla Inc.', price: 175.80, change: -1.20, vol: 'HIGH', cap: '556.2B', high: 180.20, low: 172.50 },
  { symbol: 'NVDA', name: 'NVIDIA Corp.', price: 892.45, change: 2.45, vol: 'EXTREME', cap: '2.21T', high: 900.00, low: 885.00 },
  { symbol: 'BTC', name: 'Bitcoin', price: 68450.00, change: 1.50, vol: 'HIGH', cap: '1.34T', high: 69200.00, low: 67800.00 },
  { symbol: 'ETH', name: 'Ethereum', price: 3890.00, change: 0.95, vol: 'MED', cap: '460.5B', high: 3950.00, low: 3840.00 },
  { symbol: 'SOL', name: 'Solana', price: 145.20, change: 5.40, vol: 'HIGH', cap: '64.3B', high: 148.00, low: 138.00 },
];

const INITIAL_INDICES = [
    { name: 'S&P 500', value: 5234.12, change: 12.40, percent: 0.24 },
    { name: 'NASDAQ', value: 16420.88, change: 85.20, percent: 0.52 },
    { name: 'DOW JONES', value: 39512.50, change: -45.10, percent: -0.11 },
    { name: 'RUSSELL 2K', value: 2085.30, change: 15.40, percent: 0.74 }
];

export const Dashboard: React.FC<DashboardProps> = ({ 
  stats, userProfile, settings, onUpdateSettings, 
  onOpenDepositModal, onOpenWithdrawModal, activePage, onNavigate, transactions, onUpdateUser 
}) => {
  const [liveMarkets, setLiveMarkets] = useState(() => 
    MARKETS_DATA_BASE.map(m => ({ ...m, history: Array.from({ length: 20 }, () => m.price * (1 + (Math.random() * 0.05 - 0.025))) }))
  );
  
  const [indices, setIndices] = useState(INITIAL_INDICES);
  const [isLiveBrokerOpen, setIsLiveBrokerOpen] = useState(false);
  const [chartRange, setChartRange] = useState<'1H' | '1D' | 'ALL'>('ALL');

  useEffect(() => {
    const interval = setInterval(() => {
        setLiveMarkets(prev => prev.map(m => {
            const fluctuation = (Math.random() * 0.004) - 0.002;
            const newPrice = m.price * (1 + fluctuation);
            return { ...m, price: newPrice, change: m.change + (fluctuation * 100), history: [...m.history.slice(1), newPrice] };
        }));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
        setIndices(prev => prev.map(idx => {
            const move = (Math.random() * 2 - 1) * (idx.value * 0.0002);
            const newValue = idx.value + move;
            const newChange = idx.change + move;
            return {
                ...idx,
                value: newValue,
                change: newChange,
                percent: (newChange / (newValue - newChange)) * 100
            };
        }));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const chartData = useMemo(() => {
      let current = stats.balance;
      const data = [{ time: 'NOW', value: current, timeFull: 'Live Telemetry' }];
      const slice = [...stats.history].slice(0, 50);
      slice.forEach((trade) => {
          current -= trade.amount;
          data.unshift({
            time: new Date(trade.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            value: current,
            timeFull: new Date(trade.timestamp).toLocaleString()
          });
      });
      return data;
  }, [stats.history, stats.balance]);

  const performanceMetrics = useMemo(() => {
      const history = stats.history;
      const totalTrades = history.length;
      const winningTrades = history.filter(t => t.type === 'profit');
      const losingTrades = history.filter(t => t.type === 'loss');
      
      const winRate = totalTrades > 0 ? (winningTrades.length / totalTrades) * 100 : 0;
      const bestTrade = winningTrades.length > 0 ? Math.max(...winningTrades.map(t => Math.abs(t.amount))) : 0;
      const worstTrade = losingTrades.length > 0 ? Math.max(...losingTrades.map(t => Math.abs(t.amount))) : 0;
      
      return {
          winRate,
          bestTrade,
          worstTrade,
          totalTrades
      };
  }, [stats.history]);

  return (
    <div className="max-w-[1920px] mx-auto p-4 md:p-8 space-y-6 animate-[fadeIn_0.3s] relative z-10">
        <div className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-2xl overflow-hidden mb-6">
            <TickerTape key="dashboard-ticker-tape" colorTheme="dark" displayMode="adaptive" />
        </div>
        <LiveBroker isOpen={isLiveBrokerOpen} onClose={() => setIsLiveBrokerOpen(false)} stats={stats} liveMarkets={liveMarkets} />
        
        {/* Metric Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Primary Financials */}
            <div className="lg:col-span-4 bg-black/40 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-xl relative overflow-hidden group flex flex-col justify-between hover:border-prime-cyan/30 transition-all duration-500">
                <div className="absolute inset-0 bg-gradient-to-br from-prime-cyan/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className="absolute top-0 right-0 p-16 bg-prime-cyan/10 blur-[60px] rounded-full group-hover:bg-prime-cyan/20 transition-colors duration-500"></div>
                <div className="relative z-10">
                    <h3 className="text-slate-400 text-[10px] font-black uppercase tracking-[0.25em] mb-4 font-display flex items-center gap-2">
                        Net Liquidity
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-emerald-400"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                    </h3>
                    <div className="text-4xl md:text-5xl font-mono font-bold text-white tracking-tighter drop-shadow-[0_0_15px_rgba(255,255,255,0.1)]">${stats.balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
                </div>
                <div className="flex gap-3 mt-8 relative z-10">
                    <button onClick={onOpenDepositModal} className="flex-1 py-3.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 text-[10px] font-black uppercase tracking-widest rounded-xl border border-emerald-500/20 hover:border-emerald-500/40 transition-all shadow-[0_0_15px_rgba(16,185,129,0.1)] hover:shadow-[0_0_20px_rgba(16,185,129,0.2)]">Deposit</button>
                    <button onClick={onOpenWithdrawModal} className="flex-1 py-3.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-[10px] font-black uppercase tracking-widest rounded-xl border border-rose-500/20 hover:border-rose-500/40 transition-all shadow-[0_0_15px_rgba(244,63,94,0.1)] hover:shadow-[0_0_20px_rgba(244,63,94,0.2)]">Withdraw</button>
                </div>
            </div>

            <div className="lg:col-span-3 bg-black/40 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-xl flex flex-col justify-between relative overflow-hidden group hover:border-prime-cyan/30 transition-all duration-500">
                <div className="absolute inset-0 bg-gradient-to-br from-prime-cyan/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className="absolute top-0 right-0 p-12 bg-prime-cyan/10 blur-[50px] rounded-full pointer-events-none group-hover:bg-prime-cyan/20 transition-colors duration-500"></div>
                <div className="relative z-10">
                    <h3 className="text-slate-400 text-[10px] font-black uppercase tracking-[0.25em] mb-4 font-display flex items-center gap-2">
                        Neural P/L
                        <span className="w-1.5 h-1.5 bg-prime-cyan rounded-full animate-pulse shadow-[0_0_8px_rgba(0,240,255,0.8)]"></span>
                    </h3>
                    <div className={`text-4xl md:text-5xl font-mono font-bold tracking-tighter drop-shadow-[0_0_15px_rgba(0,240,255,0.1)] ${stats.profit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {stats.profit >= 0 ? '+' : ''}${Math.abs(stats.profit).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </div>
                </div>
                <div className="flex items-center gap-3 mt-8 relative z-10 bg-white/5 p-3 rounded-xl border border-white/5">
                    <div className="relative">
                        <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></div>
                        <div className="absolute inset-0 w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping opacity-50"></div>
                    </div>
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Active Trades: <span className="text-white font-mono ml-1">{stats.trades}</span></div>
                </div>
            </div>

            {/* Trading Performance Indicators */}
            <div className="lg:col-span-5 bg-black/40 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-xl">
                <h3 className="text-slate-500 text-[9px] font-black uppercase tracking-[0.2em] mb-4 font-display">Performance Metrics</h3>
                <div className="grid grid-cols-2 gap-4 h-[calc(100%-2rem)]">
                    <div className="bg-white/5 rounded-2xl p-4 flex flex-col justify-center">
                        <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-1">Win Rate</div>
                        <div className="text-2xl font-mono font-bold text-white">{performanceMetrics.winRate.toFixed(1)}%</div>
                    </div>
                    <div className="bg-white/5 rounded-2xl p-4 flex flex-col justify-center">
                        <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-1">Total Trades</div>
                        <div className="text-2xl font-mono font-bold text-white">{performanceMetrics.totalTrades}</div>
                    </div>
                    <div className="bg-white/5 rounded-2xl p-4 flex flex-col justify-center">
                        <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-1">Best Trade</div>
                        <div className="text-xl font-mono font-bold text-emerald-400">+${performanceMetrics.bestTrade.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
                    </div>
                    <div className="bg-white/5 rounded-2xl p-4 flex flex-col justify-center">
                        <div className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-1">Worst Trade</div>
                        <div className="text-xl font-mono font-bold text-rose-400">-${performanceMetrics.worstTrade.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
                    </div>
                </div>
            </div>
        </div>

        {/* Main Interface */}
        {activePage === 'Dashboard' && (
            <>
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <div className="lg:col-span-8 space-y-6">
                    {/* Quick Actions */}
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                        <div className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-xl cursor-pointer hover:border-prime-cyan/50 hover:bg-white/[0.02] transition-all duration-300 group relative overflow-hidden" onClick={() => onNavigate('Analysis')}>
                            <div className="absolute inset-0 bg-gradient-to-br from-prime-cyan/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                            <h3 className="text-slate-500 group-hover:text-prime-cyan transition-colors text-[9px] font-black uppercase tracking-[0.2em] mb-4 font-display relative z-10">Intelligence</h3>
                            <div className="flex items-center gap-4 relative z-10">
                                <div className="w-12 h-12 bg-prime-cyan/10 rounded-2xl flex items-center justify-center text-prime-cyan border border-prime-cyan/20 group-hover:scale-110 transition-transform duration-300">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                                </div>
                                <div>
                                    <div className="text-sm font-bold text-white group-hover:text-prime-cyan transition-colors">Neural Hub</div>
                                    <div className="text-[9px] text-emerald-400 font-bold uppercase tracking-widest flex items-center gap-1 mt-1">
                                        <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                                        Encrypted
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="bg-prime-cyan/10 backdrop-blur-xl border border-prime-cyan/20 rounded-3xl p-6 shadow-xl cursor-pointer hover:bg-prime-cyan/20 hover:border-prime-cyan/40 transition-all duration-300 group relative overflow-hidden" onClick={() => setIsLiveBrokerOpen(true)}>
                            <div className="absolute inset-0 bg-gradient-to-br from-prime-cyan/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                            <h3 className="text-white text-[9px] font-black uppercase tracking-[0.2em] mb-4 font-display relative z-10">Voice Uplink</h3>
                            <div className="flex items-center gap-4 relative z-10">
                                <div className="w-12 h-12 bg-black rounded-2xl flex items-center justify-center text-prime-cyan border border-prime-cyan/40 shadow-[0_0_15px_rgba(0,240,255,0.3)] group-hover:scale-110 transition-transform duration-300">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/></svg>
                                </div>
                                <div>
                                    <div className="text-sm font-bold text-white">Live Broker</div>
                                    <div className="text-[9px] text-prime-cyan font-bold uppercase tracking-widest animate-pulse mt-1">Secure Link</div>
                                </div>
                            </div>
                        </div>

                        <div className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-xl cursor-pointer hover:border-emerald-500/50 hover:bg-white/[0.02] transition-all duration-300 group relative overflow-hidden" onClick={() => onNavigate('RealEstate')}>
                            <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                            <h3 className="text-slate-500 group-hover:text-emerald-400 transition-colors text-[9px] font-black uppercase tracking-[0.2em] mb-4 font-display relative z-10">Tangible Assets</h3>
                            <div className="flex items-center gap-4 relative z-10">
                                <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-400 border border-emerald-500/20 group-hover:scale-110 transition-transform duration-300">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 21h18"/><path d="M9 8h1"/><path d="M9 12h1"/><path d="M9 16h1"/><path d="M14 8h1"/><path d="M14 12h1"/><path d="M14 16h1"/><path d="M5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16"/></svg>
                                </div>
                                <div>
                                    <div className="text-sm font-bold text-white group-hover:text-emerald-400 transition-colors">Real Estate</div>
                                    <div className="text-[9px] text-emerald-400 font-bold uppercase tracking-widest flex items-center gap-1 mt-1">
                                        Fractional
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-xl cursor-pointer hover:border-purple-500/50 hover:bg-white/[0.02] transition-all duration-300 group relative overflow-hidden" onClick={() => onNavigate('Settings')}>
                            <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                            <h3 className="text-slate-500 group-hover:text-purple-400 transition-colors text-[9px] font-black uppercase tracking-[0.2em] mb-4 font-display relative z-10">Automation</h3>
                            <div className="flex items-center gap-4 relative z-10">
                                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border group-hover:scale-110 transition-transform duration-300 ${userProfile?.autoTrading ? 'bg-purple-500/10 text-purple-400 border-purple-500/20' : 'bg-slate-800/50 text-slate-500 border-slate-700'}`}>
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                                </div>
                                <div>
                                    <div className="text-sm font-bold text-white group-hover:text-purple-400 transition-colors">Trading Bot</div>
                                    {userProfile?.autoTrading ? (
                                        <div className="text-[9px] text-purple-400 font-bold uppercase tracking-widest flex items-center gap-1 mt-1">
                                            <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-pulse-glow"></span> Active
                                        </div>
                                    ) : (
                                        <div className="text-[9px] text-slate-500 font-bold uppercase tracking-widest flex items-center gap-1 mt-1">
                                            <span className="w-1.5 h-1.5 rounded-full bg-slate-500"></span> Offline
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Trading Bot Status Widget */}
                    <div className={`backdrop-blur-xl border rounded-[2rem] p-6 shadow-2xl relative overflow-hidden group transition-all duration-500 cursor-pointer ${userProfile?.autoTrading ? 'bg-gradient-to-br from-black/80 via-black/60 to-prime-cyan/10 border-prime-cyan/30 shadow-[0_0_40px_rgba(0,240,255,0.1)] hover:border-prime-cyan/50' : 'bg-black/40 border-white/10 hover:border-prime-cyan/30'}`} onClick={() => onNavigate('Settings')}>
                        <div className="absolute inset-0 bg-gradient-to-br from-prime-cyan/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                        <div className={`absolute top-0 right-0 p-16 blur-[50px] rounded-full pointer-events-none transition-colors duration-500 ${userProfile?.autoTrading ? 'bg-prime-cyan/20 group-hover:bg-prime-cyan/30 animate-pulse-slow' : 'bg-transparent'}`}></div>
                        
                        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 relative z-10">
                            <div className="flex items-center gap-4">
                                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center border group-hover:scale-110 transition-transform duration-300 ${userProfile?.autoTrading ? 'bg-prime-cyan/10 text-prime-cyan border-prime-cyan/20 animate-float' : 'bg-slate-800/50 text-slate-500 border-slate-700'}`}>
                                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                                </div>
                                <div>
                                    <h3 className="text-transparent bg-clip-text bg-gradient-to-r from-prime-cyan via-prime-purple to-prime-pink font-black text-lg uppercase tracking-tighter font-display flex items-center gap-2">
                                        Titan Momentum X
                                        <span className="bg-prime-cyan/20 text-prime-cyan px-2 py-0.5 rounded text-[9px] font-bold tracking-widest border border-prime-cyan/30">V4.2</span>
                                    </h3>
                                    {userProfile?.autoTrading ? (
                                        <div className="text-[10px] text-emerald-400 font-bold uppercase tracking-widest flex items-center gap-1.5 mt-1">
                                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse-glow"></span>
                                            System Active & Trading ({userProfile.activeBots || 1} Nodes)
                                        </div>
                                    ) : (
                                        <div className="text-[10px] text-slate-500 font-bold uppercase tracking-widest flex items-center gap-1.5 mt-1">
                                            <span className="w-1.5 h-1.5 rounded-full bg-slate-500"></span>
                                            System Offline
                                        </div>
                                    )}
                                </div>
                            </div>

                            <div className="grid grid-cols-3 gap-4 w-full md:w-auto">
                                <div className="bg-white/5 rounded-xl p-3 border border-white/5">
                                    <div className="text-[8px] font-bold text-slate-500 uppercase tracking-widest mb-1">Win Rate</div>
                                    <div className="text-lg font-mono font-bold text-white">78.4%</div>
                                </div>
                                <div className="bg-white/5 rounded-xl p-3 border border-white/5">
                                    <div className="text-[8px] font-bold text-slate-500 uppercase tracking-widest mb-1">24h Profit</div>
                                    <div className="text-lg font-mono font-bold text-emerald-400">+$1.2k</div>
                                </div>
                                <div className="bg-white/5 rounded-xl p-3 border border-white/5 flex items-center justify-center hover:bg-white/10 transition-colors">
                                    <div className="text-[9px] font-black text-white uppercase tracking-widest flex items-center gap-2">
                                        Configure
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-[2rem] p-8 shadow-2xl relative overflow-hidden mt-6">
                        <div className="flex justify-between items-center mb-8">
                            <h3 className="text-white font-black text-sm uppercase tracking-tighter font-display flex items-center gap-2">
                                Equity Performance
                                <span className="bg-white/5 px-2 py-0.5 rounded text-[8px] text-slate-500 font-mono tracking-wider border border-white/5">AES-256</span>
                            </h3>
                            <div className="flex gap-2">
                                {['1H', '1D', 'ALL'].map(r => (
                                    <button key={r} onClick={() => setChartRange(r as any)} className={`px-3 py-1 rounded text-[9px] font-black uppercase transition-all ${chartRange === r ? 'bg-white text-black' : 'text-slate-500 bg-black/40'}`}>{r}</button>
                                ))}
                            </div>
                        </div>
                        <div className="h-[400px]">
                            <ResponsiveContainer width="100%" height="100%">
                                <AreaChart data={chartData}>
                                    <defs><linearGradient id="eqG" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#00F0FF" stopOpacity={0.2}/><stop offset="100%" stopColor="#00F0FF" stopOpacity={0}/></linearGradient></defs>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                                    <XAxis dataKey="time" hide />
                                    <YAxis stroke="#ffffff20" fontSize={9} axisLine={false} tickLine={false} tickFormatter={v=>`$${v.toLocaleString()}`} />
                                    <Tooltip contentStyle={{backgroundColor: '#000', border: 'none', borderRadius: '8px'}} />
                                    <Area type="monotone" dataKey="value" stroke="#00F0FF" strokeWidth={2} fill="url(#eqG)" />
                                </AreaChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                </div>

                <div className="lg:col-span-4 space-y-6">
                    <LocalMLWidget symbol={liveMarkets[0]?.symbol || 'TSLA'} currentPrice={liveMarkets[0]?.price || 175.80} />
                    
                    {/* Command Feed */}
                    <div className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-[2rem] p-8 shadow-2xl h-80 overflow-hidden flex flex-col relative group hover:border-prime-cyan/30 transition-all duration-500">
                        <div className="absolute top-0 right-0 p-16 bg-prime-cyan/5 blur-[50px] rounded-full pointer-events-none group-hover:bg-prime-cyan/10 transition-colors"></div>
                        <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-6 flex items-center gap-3 relative z-10">
                            <div className="relative">
                                <div className="w-2 h-2 bg-prime-cyan rounded-full animate-pulse"></div>
                                <div className="absolute inset-0 w-2 h-2 bg-prime-cyan rounded-full animate-ping opacity-50"></div>
                            </div>
                            Command Center Feed [E2EE]
                        </h4>
                        <div className="flex-1 overflow-y-auto space-y-3 font-mono text-[11px] scrollbar-hide relative z-10">
                            {stats.history.length === 0 ? (
                                <div className="text-slate-700 italic flex items-center gap-2">
                                    <span className="w-1 h-3 bg-slate-800 animate-pulse"></span>
                                    SYSTEM IDLE. AWAITING MARKET SIGNALS...
                                </div>
                            ) : (
                                stats.history.map(h => (
                                    <div key={h.id} className="flex gap-4 p-3 bg-white/[0.02] border border-white/5 rounded-xl group/item hover:bg-white/[0.05] transition-all hover:border-white/10">
                                        <span className="text-slate-600 font-bold">[{new Date(h.timestamp).toLocaleTimeString([], {hour12: false})}]</span>
                                        <span className={`flex-1 ${h.type === 'profit' ? 'text-emerald-400' : 'text-rose-400'} font-medium`}>{h.message}</span>
                                        <span className="font-black text-white tracking-tighter">${Math.abs(h.amount).toFixed(2)}</span>
                                    </div>
                                ))
                            )}
                        </div>
                        <div className="absolute bottom-0 left-0 w-full h-12 bg-gradient-to-t from-black/40 to-transparent pointer-events-none"></div>
                    </div>

                    <NewsFeed />
                </div>
            </div>
            
            <div className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-[2rem] p-6 shadow-xl mt-6 overflow-hidden">
                <h4 className="text-white font-black text-xs uppercase tracking-widest mb-6 border-b border-white/5 pb-4">Global Market Intelligence</h4>
                <div className="h-[450px] -mx-2">
                    <MarketOverview 
                        key="dashboard-market-overview"
                        colorTheme="dark" 
                        height={450} 
                        width="100%" 
                        showFloatingTooltip
                        tabs={[
                            {
                                title: "Indices",
                                symbols: [
                                    { s: "FOREXCOM:SPXUSD", d: "S&P 500" },
                                    { s: "FOREXCOM:NSXUSD", d: "US 100" },
                                    { s: "FOREXCOM:DJI", d: "Dow 30" },
                                    { s: "INDEX:NKY", d: "Nikkei 225" },
                                    { s: "INDEX:DEU40", d: "DAX Index" },
                                    { s: "FOREXCOM:UKXGBP", d: "UK 100" }
                                ],
                                originalTitle: "Indices"
                            },
                            {
                                title: "Crypto",
                                symbols: [
                                    { s: "BINANCE:BTCUSDT", d: "Bitcoin" },
                                    { s: "BINANCE:ETHUSDT", d: "Ethereum" },
                                    { s: "BINANCE:SOLUSDT", d: "Solana" },
                                    { s: "BINANCE:XRPUSDT", d: "Ripple" }
                                ],
                                originalTitle: "Crypto"
                            }
                        ]}
                    />
                </div>
                <button onClick={() => onNavigate('Markets')} className="w-full mt-6 py-3 bg-white/5 hover:bg-white/10 rounded-xl text-[9px] font-black uppercase tracking-widest text-slate-400 hover:text-white transition-all">Deep Market Analysis</button>
            </div>
        </>
        )}

        {/* Placeholder views for other pages */}
        {activePage === 'Settings' && (
            <SettingsPanel 
                userProfile={userProfile} 
                settings={settings} 
                onUpdateSettings={onUpdateSettings} 
                onUpdateUser={onUpdateUser}
            />
        )}

        {activePage === 'Ledger' && (
            <div className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-[2rem] p-8 shadow-2xl animate-[fadeIn_0.3s]">
                <h3 className="text-white font-black uppercase tracking-widest text-xs border-b border-white/10 pb-4 mb-6">Transaction Ledger</h3>
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="text-[9px] font-black text-slate-500 uppercase tracking-widest border-b border-white/5">
                            <tr>
                                <th className="pb-4">TX-ID</th>
                                <th className="pb-4">Date</th>
                                <th className="pb-4">Type</th>
                                <th className="pb-4">Amount</th>
                                <th className="pb-4">Status</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5 text-xs font-mono">
                            {!transactions || transactions.filter(t => t.userId === userProfile?.id).length === 0 ? (
                                <tr><td colSpan={5} className="py-8 text-center text-slate-600">No transactions found.</td></tr>
                            ) : (
                                transactions.filter(t => t.userId === userProfile?.id).map(t => (
                                    <tr key={t.id} className="hover:bg-white/[0.02] transition-colors">
                                        <td className="py-4 text-slate-400">{t.id}</td>
                                        <td className="py-4 text-slate-400">{new Date(t.date).toLocaleString()}</td>
                                        <td className="py-4 uppercase text-[10px] font-bold">{t.type}</td>
                                        <td className={`py-4 font-bold ${t.type === 'deposit' || t.type === 'profit' ? 'text-emerald-400' : 'text-rose-400'}`}>
                                            {t.type === 'deposit' || t.type === 'profit' ? '+' : '-'}${t.amount.toLocaleString(undefined, {minimumFractionDigits: 2})}
                                        </td>
                                        <td className="py-4">
                                            <span className={`px-2 py-1 rounded text-[9px] font-black uppercase tracking-widest ${
                                                t.status === 'completed' ? 'bg-emerald-500/10 text-emerald-400' :
                                                t.status === 'pending' ? 'bg-amber-500/10 text-amber-400' :
                                                'bg-rose-500/10 text-rose-400'
                                            }`}>{t.status}</span>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        )}

        {activePage === 'Markets' && <MarketView />}
        {activePage === 'Strategies' && <Marketplace />}
        {activePage === 'Portfolio' && <Portfolio userProfile={userProfile} />}
        {activePage === 'Funds' && <Liquidity onOpenDepositModal={onOpenDepositModal} onOpenWithdrawModal={onOpenWithdrawModal} stats={stats} />}
        {activePage === 'Analysis' && <Intel />}
        {activePage === 'RealEstate' && <RealEstateDashboard />}
    </div>
  );
};

export default Dashboard;