import React, { useState, useEffect } from 'react';
import { User } from '../types';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts';

interface PortfolioItem {
  id: string;
  symbol: string;
  shares: number;
  avgPrice: number;
  currentPrice: number;
}

interface PortfolioProps {
  userProfile?: User;
}

const COLORS = ['#00f0ff', '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

export const Portfolio: React.FC<PortfolioProps> = ({ userProfile }) => {
  const [items, setItems] = useState<PortfolioItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [newSymbol, setNewSymbol] = useState('');
  const [newShares, setNewShares] = useState('');
  const [newPrice, setNewPrice] = useState('');

  useEffect(() => {
    if (!userProfile) return;
    
    const fetchPortfolio = () => {
      try {
        const saved = localStorage.getItem(`prime_ai_portfolio_${userProfile.id}`);
        if (saved) {
          setItems(JSON.parse(saved));
        } else {
          // Initialize with some mock data for demo purposes
          const mockData = [
            { id: '1', symbol: 'TSLA', shares: 150, avgPrice: 165.20, currentPrice: 175.80 },
            { id: '2', symbol: 'NVDA', shares: 45, avgPrice: 750.00, currentPrice: 892.45 },
            { id: '3', symbol: 'BTC', shares: 0.5, avgPrice: 62000.00, currentPrice: 68450.00 },
            { id: '4', symbol: 'ETH', shares: 12, avgPrice: 3200.00, currentPrice: 3450.00 }
          ];
          setItems(mockData);
          localStorage.setItem(`prime_ai_portfolio_${userProfile.id}`, JSON.stringify(mockData));
        }
      } catch (error) {
        console.error("Error fetching portfolio:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchPortfolio();
  }, [userProfile]);

  useEffect(() => {
    if (!userProfile || loading) return;
    localStorage.setItem(`prime_ai_portfolio_${userProfile.id}`, JSON.stringify(items));
  }, [items, userProfile, loading]);

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userProfile || !newSymbol || !newShares || !newPrice) return;

    const newItem: PortfolioItem = {
      id: `pos-${Date.now()}`,
      symbol: newSymbol.toUpperCase(),
      shares: parseFloat(newShares),
      avgPrice: parseFloat(newPrice),
      currentPrice: parseFloat(newPrice) * (1 + (Math.random() * 0.1 - 0.05)), // Mock current price
    };

    setItems([...items, newItem]);
    setNewSymbol('');
    setNewShares('');
    setNewPrice('');
  };

  const handleDeleteItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  if (loading) {
    return <div className="p-8 text-center text-slate-500 font-mono">Loading portfolio data...</div>;
  }

  const totalValue = items.reduce((acc, item) => acc + (item.shares * item.currentPrice), 0);
  const totalCost = items.reduce((acc, item) => acc + (item.shares * item.avgPrice), 0);
  const totalProfit = totalValue - totalCost;
  const profitPercent = totalCost > 0 ? (totalProfit / totalCost) * 100 : 0;

  const chartData = items.map(item => ({
    name: item.symbol,
    value: item.shares * item.currentPrice
  })).sort((a, b) => b.value - a.value);

  return (
    <div className="space-y-8 animate-[fadeIn_0.3s]">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-2 h-2 bg-prime-cyan rounded-full animate-pulse"></div>
            <span className="text-[10px] font-black text-prime-cyan uppercase tracking-[0.3em]">Live Sync Active</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-white uppercase tracking-tighter font-display mb-2">Investment Portfolio</h2>
          <p className="text-slate-400 text-sm font-mono max-w-xl">Real-time tracking of your institutional-grade asset allocation and algorithmic performance.</p>
        </div>
        <div className="text-left md:text-right bg-black/40 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-2xl">
          <div className="text-[10px] text-slate-500 font-black uppercase tracking-widest mb-1">Total Asset Value</div>
          <div className="text-4xl font-mono font-bold text-white mb-2">${totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
          <div className={`text-sm font-bold font-mono flex items-center md:justify-end gap-2 ${totalProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            <span className={`px-2 py-0.5 rounded ${totalProfit >= 0 ? 'bg-emerald-500/10' : 'bg-rose-500/10'}`}>
              {totalProfit >= 0 ? '▲' : '▼'} {Math.abs(profitPercent).toFixed(2)}%
            </span>
            <span>{totalProfit >= 0 ? '+' : ''}${totalProfit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} All Time</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Allocation Chart */}
        <div className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-[2rem] p-8 shadow-xl flex flex-col">
          <h3 className="text-white font-black uppercase tracking-widest text-xs border-b border-white/10 pb-4 mb-6">Asset Allocation</h3>
          {items.length > 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center">
              <div className="h-[200px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={chartData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                      stroke="none"
                    >
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value: number) => `$${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
                      contentStyle={{ backgroundColor: 'rgba(0,0,0,0.8)', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '8px', color: '#fff', fontSize: '12px', fontFamily: 'monospace' }}
                      itemStyle={{ color: '#fff' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="w-full mt-6 grid grid-cols-2 gap-3">
                {chartData.slice(0, 4).map((entry, index) => (
                  <div key={entry.name} className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }}></div>
                    <div className="text-[10px] font-mono text-slate-300">{entry.name} <span className="text-slate-500">({((entry.value / totalValue) * 100).toFixed(1)}%)</span></div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-slate-600 text-xs font-mono">No allocation data</div>
          )}
        </div>

        {/* Current Positions */}
        <div className="lg:col-span-2 bg-black/40 backdrop-blur-xl border border-white/10 rounded-[2rem] p-8 shadow-xl flex flex-col">
          <div className="flex justify-between items-center border-b border-white/10 pb-4 mb-6">
            <h3 className="text-white font-black uppercase tracking-widest text-xs">Current Positions</h3>
            <span className="text-[10px] font-mono text-slate-500">{items.length} Active Assets</span>
          </div>
          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left">
              <thead className="text-[9px] font-black text-slate-500 uppercase tracking-widest border-b border-white/5">
                <tr>
                  <th className="pb-4">Asset</th>
                  <th className="pb-4">Shares</th>
                  <th className="pb-4">Avg Price</th>
                  <th className="pb-4">Current Price</th>
                  <th className="pb-4">P/L</th>
                  <th className="pb-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-xs font-mono">
                {items.length === 0 ? (
                  <tr><td colSpan={6} className="py-8 text-center text-slate-600">No positions found. Add an asset to start tracking.</td></tr>
                ) : (
                  items.map(item => {
                    const profit = (item.currentPrice - item.avgPrice) * item.shares;
                    const percent = ((item.currentPrice - item.avgPrice) / item.avgPrice) * 100;
                    return (
                      <tr key={item.id} className="hover:bg-white/[0.02] transition-colors group">
                        <td className="py-4 font-bold text-white flex items-center gap-2">
                          <div className="w-6 h-6 rounded-full bg-white/5 flex items-center justify-center text-[8px] border border-white/10">{item.symbol.substring(0,2)}</div>
                          {item.symbol}
                        </td>
                        <td className="py-4 text-slate-400">{item.shares.toLocaleString()}</td>
                        <td className="py-4 text-slate-400">${item.avgPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                        <td className="py-4 text-white">${item.currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                        <td className={`py-4 font-bold ${profit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {profit >= 0 ? '+' : ''}${profit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} 
                          <span className="text-[10px] ml-1 opacity-80">({percent >= 0 ? '+' : ''}{percent.toFixed(2)}%)</span>
                        </td>
                        <td className="py-4 text-right">
                          <button onClick={() => handleDeleteItem(item.id)} className="opacity-0 group-hover:opacity-100 text-rose-400 hover:text-rose-300 text-[10px] uppercase font-black tracking-widest transition-opacity bg-rose-500/10 px-3 py-1.5 rounded">Close</button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Add Position Form */}
      <div className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-[2rem] p-8 shadow-xl">
        <h3 className="text-white font-black uppercase tracking-widest text-xs border-b border-white/10 pb-4 mb-6">Add Manual Position</h3>
        <form onSubmit={handleAddItem} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
          <div>
            <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Asset Symbol</label>
            <input 
              type="text" 
              value={newSymbol}
              onChange={(e) => setNewSymbol(e.target.value)}
              placeholder="e.g. TSLA"
              className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-white font-mono text-sm focus:outline-none focus:border-prime-cyan/50 transition-colors"
              required
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Shares / Amount</label>
            <input 
              type="number" 
              step="any"
              value={newShares}
              onChange={(e) => setNewShares(e.target.value)}
              placeholder="0.00"
              className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-white font-mono text-sm focus:outline-none focus:border-prime-cyan/50 transition-colors"
              required
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Average Price ($)</label>
            <input 
              type="number" 
              step="any"
              value={newPrice}
              onChange={(e) => setNewPrice(e.target.value)}
              placeholder="0.00"
              className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-white font-mono text-sm focus:outline-none focus:border-prime-cyan/50 transition-colors"
              required
            />
          </div>
          <button type="submit" className="w-full py-3 bg-prime-cyan text-black font-black uppercase tracking-widest text-[10px] rounded-xl hover:bg-white transition-all h-[46px]">
            Add to Portfolio
          </button>
        </form>
      </div>
    </div>
  );
};

export default Portfolio;
